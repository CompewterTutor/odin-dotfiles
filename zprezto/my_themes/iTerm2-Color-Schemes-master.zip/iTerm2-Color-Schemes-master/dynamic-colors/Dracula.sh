#!/bin/sh
# Dracula
printf "\033]4;0;#000000;1;#ff5555;2;#50fa7b;3;#f1fa8c;4;#bd93f9;5;#ff79c6;6;#8be9fd;7;#bbbbbb;8;#555555;9;#ff5555;10;#50fa7b;11;#f1fa8c;12;#bd93f9;13;#ff79c6;14;#8be9fd;15;#ffffff\007"
printf "\033]10;#f8f8f2;#1e1f29;#bbbbbb\007"
printf "\033]17;#44475a\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
