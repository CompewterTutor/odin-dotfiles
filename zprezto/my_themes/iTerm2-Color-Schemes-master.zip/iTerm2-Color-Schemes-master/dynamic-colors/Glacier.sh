#!/bin/sh
# Glacier
printf "\033]4;0;#2e343c;1;#bd0f2f;2;#35a770;3;#fb9435;4;#1f5872;5;#bd2523;6;#778397;7;#ffffff;8;#404a55;9;#bd0f2f;10;#49e998;11;#fddf6e;12;#2a8bc1;13;#ea4727;14;#a0b6d3;15;#ffffff\007"
printf "\033]10;#ffffff;#0c1115;#6c6c6c\007"
printf "\033]17;#bd2523\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
