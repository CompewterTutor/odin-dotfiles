#!/bin/sh
# AdventureTime
printf "\033]4;0;#050404;1;#bd0013;2;#4ab118;3;#e7741e;4;#0f4ac6;5;#665993;6;#70a598;7;#f8dcc0;8;#4e7cbf;9;#fc5f5a;10;#9eff6e;11;#efc11a;12;#1997c6;13;#9b5953;14;#c8faf4;15;#f6f5fb\007"
printf "\033]10;#f8dcc0;#1f1d45;#efbf38\007"
printf "\033]17;#706b4e\007"
printf "\033]19;#f3d9c4\007"
printf "\033]5;0;#bd0013\007"
