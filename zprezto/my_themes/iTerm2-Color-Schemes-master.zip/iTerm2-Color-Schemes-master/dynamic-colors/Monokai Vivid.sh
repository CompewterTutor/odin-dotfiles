#!/bin/sh
# Monokai Vivid
printf "\033]4;0;#121212;1;#fa2934;2;#98e123;3;#fff30a;4;#0443ff;5;#f800f8;6;#01b6ed;7;#ffffff;8;#838383;9;#f6669d;10;#b1e05f;11;#fff26d;12;#0443ff;13;#f200f6;14;#51ceff;15;#ffffff\007"
printf "\033]10;#f9f9f9;#121212;#fb0007\007"
printf "\033]17;#ffffff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
