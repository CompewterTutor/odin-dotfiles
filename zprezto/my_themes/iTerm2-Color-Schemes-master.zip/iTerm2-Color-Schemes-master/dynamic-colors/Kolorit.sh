#!/bin/sh
# Kolorit
printf "\033]4;0;#1d1a1e;1;#ff5b82;2;#47d7a1;3;#e8e562;4;#5db4ee;5;#da6cda;6;#57e9eb;7;#ededed;8;#1d1a1e;9;#ff5b82;10;#47d7a1;11;#e8e562;12;#5db4ee;13;#da6cda;14;#57e9eb;15;#ededed\007"
printf "\033]10;#efecec;#1d1a1e;#c7c7c7\007"
printf "\033]17;#e1925c\007"
printf "\033]19;#1d1a1e\007"
printf "\033]5;0;#ff5b82\007"
