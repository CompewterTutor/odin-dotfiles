#!/bin/sh
# Spiderman
printf "\033]4;0;#1b1d1e;1;#e60813;2;#e22928;3;#e24756;4;#2c3fff;5;#2435db;6;#3256ff;7;#fffef6;8;#505354;9;#ff0325;10;#ff3338;11;#fe3a35;12;#1d50ff;13;#747cff;14;#6184ff;15;#fffff9\007"
printf "\033]10;#e3e3e3;#1b1d1e;#2c3fff\007"
printf "\033]17;#070e50\007"
printf "\033]19;#f0272d\007"
printf "\033]5;0;#ffffff\007"
