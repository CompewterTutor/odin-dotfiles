#!/bin/sh
# IC_Green_PPL
printf "\033]4;0;#1f1f1f;1;#fb002a;2;#339c24;3;#659b25;4;#149b45;5;#53b82c;6;#2cb868;7;#e0ffef;8;#032710;9;#a7ff3f;10;#9fff6d;11;#d2ff6d;12;#72ffb5;13;#50ff3e;14;#22ff71;15;#daefd0\007"
printf "\033]10;#d9efd3;#3a3d3f;#42ff58\007"
printf "\033]17;#2b9b35\007"
printf "\033]19;#d8efd5\007"
printf "\033]5;0;#9fff6d\007"
