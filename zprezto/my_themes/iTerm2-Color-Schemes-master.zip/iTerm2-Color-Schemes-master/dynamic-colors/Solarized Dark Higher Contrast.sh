#!/bin/sh
# Solarized Dark Higher Contrast
printf "\033]4;0;#002831;1;#d11c24;2;#6cbe6c;3;#a57706;4;#2176c7;5;#c61c6f;6;#259286;7;#eae3cb;8;#006488;9;#f5163b;10;#51ef84;11;#b27e28;12;#178ec8;13;#e24d8e;14;#00b39e;15;#fcf4dc\007"
printf "\033]10;#9cc2c3;#001e27;#f34b00\007"
printf "\033]17;#003748\007"
printf "\033]19;#7a8f8e\007"
printf "\033]5;0;#b5d5d3\007"
