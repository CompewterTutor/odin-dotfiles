#!/bin/sh
# purplepeter
printf "\033]4;0;#0a0520;1;#ff796d;2;#99b481;3;#efdfac;4;#66d9ef;5;#e78fcd;6;#ba8cff;7;#ffba81;8;#100b23;9;#f99f92;10;#b4be8f;11;#f2e9bf;12;#79daed;13;#ba91d4;14;#a0a0d6;15;#b9aed3\007"
printf "\033]10;#ece7fa;#2a1a4a;#c7c7c7\007"
printf "\033]17;#8689c2\007"
printf "\033]19;#271c50\007"
printf "\033]5;0;#ffffff\007"
