#!/bin/sh
# Jackie Brown
printf "\033]4;0;#2c1d16;1;#ef5734;2;#2baf2b;3;#bebf00;4;#246eb2;5;#d05ec1;6;#00acee;7;#bfbfbf;8;#666666;9;#e50000;10;#86a93e;11;#e5e500;12;#0000ff;13;#e500e5;14;#00e5e5;15;#e5e5e5\007"
printf "\033]10;#ffcc2f;#2c1d16;#23ff18\007"
printf "\033]17;#af8d21\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffcc2f\007"
