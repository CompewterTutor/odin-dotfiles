#!/bin/sh
# cyberpunk
printf "\033]4;0;#000000;1;#ff7092;2;#00fbac;3;#fffa6a;4;#00bfff;5;#df95ff;6;#86cbfe;7;#ffffff;8;#000000;9;#ff8aa4;10;#21f6bc;11;#fff787;12;#1bccfd;13;#e6aefe;14;#99d6fc;15;#ffffff\007"
printf "\033]10;#e5e5e5;#332a57;#21f6bc\007"
printf "\033]17;#c1deff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
