#!/bin/sh
# FrontEndDelight
printf "\033]4;0;#242526;1;#f8511b;2;#565747;3;#fa771d;4;#2c70b7;5;#f02e4f;6;#3ca1a6;7;#adadad;8;#5fac6d;9;#f74319;10;#74ec4c;11;#fdc325;12;#3393ca;13;#e75e4f;14;#4fbce6;15;#8c735b\007"
printf "\033]10;#adadad;#1b1c1d;#cdcdcd\007"
printf "\033]17;#ea6154\007"
printf "\033]19;#1b1c1d\007"
printf "\033]5;0;#cdcdcd\007"
