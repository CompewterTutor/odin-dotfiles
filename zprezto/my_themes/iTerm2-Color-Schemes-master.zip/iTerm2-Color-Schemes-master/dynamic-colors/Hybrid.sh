#!/bin/sh
# Hybrid
printf "\033]4;0;#2a2e33;1;#b84d51;2;#b3bf5a;3;#e4b55e;4;#6e90b0;5;#a17eac;6;#7fbfb4;7;#b5b9b6;8;#1d1f22;9;#8d2e32;10;#798431;11;#e58a50;12;#4b6b88;13;#6e5079;14;#4d7b74;15;#5a626a\007"
printf "\033]10;#b7bcba;#161719;#b7bcba\007"
printf "\033]17;#1e1f22\007"
printf "\033]19;#b7bcba\007"
printf "\033]5;0;#b7bcba\007"
