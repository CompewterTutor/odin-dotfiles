#!/bin/sh
# VibrantInk
printf "\033]4;0;#878787;1;#ff6600;2;#ccff04;3;#ffcc00;4;#44b4cc;5;#9933cc;6;#44b4cc;7;#f5f5f5;8;#555555;9;#ff0000;10;#00ff00;11;#ffff00;12;#0000ff;13;#ff00ff;14;#00ffff;15;#e5e5e5\007"
printf "\033]10;#ffffff;#000000;#ffffff\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
