#!/bin/sh
# Operator Mono Dark
printf "\033]4;0;#5a5a5a;1;#ca372d;2;#4d7b3a;3;#d4d697;4;#4387cf;5;#b86cb4;6;#72d5c6;7;#ced4cd;8;#9a9b99;9;#c37d62;10;#83d0a2;11;#fdfdc5;12;#89d3f6;13;#ff2c7a;14;#82eada;15;#fdfdf6\007"
printf "\033]10;#c3cac2;#191919;#fcdc08\007"
printf "\033]17;#19273b\007"
printf "\033]19;#dde5dc\007"
printf "\033]5;0;#fefdbf\007"
